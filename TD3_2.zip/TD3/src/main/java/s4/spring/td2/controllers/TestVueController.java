package s4.spring.td2.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import io.github.jeemv.springboot.vuejs.VueJS;
import io.github.jeemv.springboot.vuejs.utilities.Http;
import io.github.jeemv.springboot.vuejs.utilities.JsArray;
import s4.spring.td2.entities.Organization;
import s4.spring.td2.repositories.OrgasRepository;

@Controller
@RequestMapping("/vue/")
public class TestVueController {

	@Autowired
	private VueJS vue;

	@Autowired
	private OrgasRepository repo;

	@GetMapping("test")
	public String test(Model model) {
		model.addAttribute("vue", vue);

		vue.addMethod("update", "this.message='Message Modifie !';");
		vue.addMethod("testAjax", "var self=this;" + Http.post("/vue/test/ajax", "{v:self.inputValue}",
				"self.ajaxMessage = response.data; self.alertVisible = true;"));

		vue.addData("message", "Hello Campus 3!");
		vue.addData("alertVisible", false);
		vue.addData("ajaxMessage");
		vue.addData("inputValue");

		return "vueJs/test";
	}

	@PostMapping("test/ajax")
	@ResponseBody
	public String testAjax(@RequestBody String v) {
		return "Test ok :" + v;
	}

	@GetMapping("orgas")
	public String geneSpaOrgas(Model model) {

		model.addAttribute("vue", vue);
		List<Organization> orgas = repo.findAll();
		vue.addData("orgas", orgas);
		vue.addData("dialog", false);
		vue.addDataRaw("headers",
				"["
				+ "{text:'Name', value:'name'},"
				+ "{text:'Domain', value:'domain'},"
				+ "{text:'Aliases', value:'aliases'}]");
		vue.addDataRaw("editedItem", "{}");
		vue.addDataRaw("editedIndex", "-1");
		vue.addDataRaw("formTitle", " (this.itemIndex==-1)?'Nouvelle orga':'Modification organisation' ");
		vue.addMethod("close", "this.dialog=false");
		
		//ajouter
		vue.addMethod(
				"save", 
				"var self=this;" + Http.post(
						"/rest/orgas/create",
						"self.editedItem",
				"self.ajaxMessage = response.data; self.dialog=false; self.orgas.push(response.data);"));
		
		//supprimer
		vue.addMethod(
				"deleteItem",
				"var self=this;" + Http.delete(
						"/rest/orgas/delete",
						(Object)"{data: orga}",
						JsArray.remove("self.orgas", "orga")),
				"orga");
		
		// MAJ
		
		return "vueJs/index";
	}
}
