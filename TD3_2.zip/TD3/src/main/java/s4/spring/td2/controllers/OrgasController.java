package s4.spring.td2.controllers;

import java.util.List;
import java.util.Optional;

import org.aspectj.weaver.ast.Or;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.view.RedirectView;

import s4.spring.td2.entities.Groupe;
import s4.spring.td2.entities.Organization;
import s4.spring.td2.repositories.GroupesRepo;
import s4.spring.td2.repositories.OrgasRepository;

@Controller
@RequestMapping("/orgas/")
public class OrgasController {

	@Autowired
	private OrgasRepository orgasRepo;
	@Autowired
	private GroupesRepo repoGroupes;

	// ---------------------------TD2---------------------------------
	// plusieurs solutions pour afficher page index a� route : orgas/ ou orgas/index
	// @RequestMapping("{path:index?}")
	// @ResponseBody

	@GetMapping({ "", "index" })
	public String index(Model model) {
		List<Organization> orgas = orgasRepo.findAll();
		model.addAttribute("orgas", orgas);
		return "orgas/index";
	}

	// ------------------------------------------------------------------------------
	@PostMapping("new/submit")
	public RedirectView submit(Organization postedOrga) {
		if (postedOrga.getId() != 0) {
			int id = postedOrga.getId();
			Optional<Organization> opt = orgasRepo.findById(id);
			if (opt.isPresent()) {
				Organization orga = opt.get();
				copyFrom(postedOrga, orga);
				orgasRepo.save(orga);
			}
		} else {
			orgasRepo.save(postedOrga); // car nouveau si ya pas id
		}
		return new RedirectView("/orgas/");
	}

	private void copyFrom(Organization source, Organization dest) {
		dest.setName(source.getName());
		dest.setDomain(source.getDomain());
		dest.setAliases(source.getAliases());
	}
	// ------------------------------------------------------------------------------

	@GetMapping("new")
	public String ajouterOrganisation(Model model) {
		model.addAttribute("orga", new Organization());
		return "orgas/new";
	}

	/*
	 * @GetMapping("new") public String ajouterOrganisation(@RequestParam String
	 * Name, @RequestParam String Domain,
	 * 
	 * @RequestParam String Alisases) { if (Name != "" && Name != "" && Name != "")
	 * { Organization or = new Organization(); or.setName(Name);
	 * or.setDomain(Domain); or.setAliases(Alisases); orgasRepo.save(or); return
	 * "orgas/new"; } else { return "Echec Insertion"; } }
	 */

	@GetMapping("edit/{id}")
	public String modifierOrganisation(@PathVariable int id, Model model) {
		Optional<Organization> opt = orgasRepo.findById(id);
		if (opt.isPresent()) {
			model.addAttribute("orga", opt.get());
			return "orgas/edit";
		}
		return "Echec modification";
	}

	@RequestMapping("display/{id}")
	@ResponseBody
	public String displayOrganisation(@PathVariable int id, Model model) {
		Optional<Organization> opt = orgasRepo.findById(id);
		if (opt.isPresent()) {
			return "orgas/display";
		}
		return "Echec affichage";
	}

	@GetMapping("delete/{id}")
	public String deleteOrganisation(@PathVariable int id, Model model) {
		Optional<Organization> opt = orgasRepo.findById(id);
		if (opt.isPresent()) {

			return "orgas/edit";
		}
		return "Echec suppression : cette entreprise n'existe pas.";
	}

	// --------------------------------------------------------------
	@RequestMapping("create")
	@ResponseBody
	public String createOrga() {
		Organization or = new Organization();

		or.setName("IUT Ifs");
		or.setDomain("unicaen.fr");
		or.setAliases("iutc3.unicaen.fr");
		or.setVille("Ifs");

		orgasRepo.save(or);
		return or + " ajoute dans la BDD";
	}

	@RequestMapping("groupes")
	@ResponseBody
	public String createGroupe() {
		Groupe groupe = new Groupe();
		repoGroupes.save(groupe);
		return "Groupe cree";
	}

	// --------------------------------------------------------------
	@RequestMapping("create/groupes/{id}")
	@ResponseBody
	public String createOrgaWithGroupes(@PathVariable int id) {
		Optional<Organization> optOrga = orgasRepo.findById(id);
		if (optOrga.isPresent()) {
			Organization or = optOrga.get();
			Groupe groupe = new Groupe();
			groupe.setName("Etudiants");

			or.addGroup(groupe);
			orgasRepo.save(or);
			return or + " ajoute dans la BDD";
		}
		return "Organization n'existe pas";
	}

}
