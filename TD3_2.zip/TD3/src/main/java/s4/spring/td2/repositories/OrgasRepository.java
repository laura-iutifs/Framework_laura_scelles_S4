package s4.spring.td2.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import s4.spring.td2.entities.Organization;

// JpaRepository<T, ID>  t = classe metier ID = integer

public interface OrgasRepository extends JpaRepository<Organization, Integer> {

}
