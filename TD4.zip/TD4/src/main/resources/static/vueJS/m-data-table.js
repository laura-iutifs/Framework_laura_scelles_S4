//Script generated with VueComponent at Wed Mar 13 11:57:29 CET 2019
Vue.component('m-data-table',{
	"props":{
		headers:{
			"type":[Array],"required":true
			}
		,noData:{
			"default":"Aucun element a afficher"
			}
		,items:{
			"type":[Array],"required":true
			}
		}
	,"template":"<div>    <v-data-table :headers=\"headers\" :items=\"desserts\" class=\"elevation-1\"> <template v-slot:items=\"props\">    <td v-if=\"header in headers\">{{ props.item[header.value] }}</td>    <v-icon small class=\"mr-2\" @click=\"$emit('edititem', props.item)\">    edit </v-icon>         <v-icon small class=\"mr-2\" @click=\"$emit('edititem', props.item)\">    delete </v-icon>         </template> <template v-slot:no-data>{{noData}} </template>     </v-data-table></div>"
	}
);