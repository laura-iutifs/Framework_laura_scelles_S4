package s4.spring.td2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Td2Application {

	public static void main(String[] args) {
		SpringApplication.run(Td2Application.class, args);
	}

}

